use std::error::Error;
use std::sync::Arc;
use std::path::Path;
use teloxide::{prelude::*, utils::command::BotCommands, types::{InlineKeyboardButton, InlineKeyboardMarkup}};
use dotenv::dotenv;
use tokio::sync::Mutex;
use warp::{Filter, filters::BoxedFilter, reply::Reply};
use url::Url;
use regex;
use warp::http::header::{HeaderMap, HeaderValue, ACCESS_CONTROL_ALLOW_ORIGIN, ACCESS_CONTROL_ALLOW_METHODS, ACCESS_CONTROL_ALLOW_HEADERS};
use warp::http::StatusCode;
use tokio::sync::Mutex as TokioMutex;
use serde::{Serialize, Deserialize};
use std::fs;

// Import our models module
mod models;
use models::{BotData, MenuItem, load_bot_data};

// Import for dialog state management
use std::collections::HashMap;

#[derive(BotCommands, Clone)]
#[command(rename_rule = "lowercase", description = "Available commands:")]
enum Command {
    #[command(description = "Start the bot")]
    Start,
    #[command(description = "Help message")]
    Help,
    #[command(description = "Show options")]
    Options,
    #[command(description = "Show main menu")]
    Menu,
    #[command(description = "Show frequently asked questions")]
    Faq,
}

// Server endpoints will return this JSON response
#[derive(Serialize, Deserialize)]
struct ApiResponse {
    success: bool,
    message: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    data: Option<serde_json::Value>,
}

// Shared state to track some data between bot and web server
#[derive(Clone)]
struct AppState {
    message_count: usize,
    bot_data: BotData,
    search_states: Arc<TokioMutex<HashMap<ChatId, bool>>>,
}

impl Default for AppState {
    fn default() -> Self {
        // Default empty bot data, will be replaced with actual data when loaded
        Self {
            message_count: 0,
            bot_data: BotData {
                title: String::new(),
                main_menu: Vec::new(),
                faq: Vec::new(),
            },
            search_states: Arc::new(TokioMutex::new(HashMap::new())),
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    // Initialize logger
    pretty_env_logger::init();
    log::info!("Starting telegram bot and web server");
    
    // Load environment variables from .env file
    dotenv().ok();
    
    // Load bot data from JSON file
    let bot_data_path = "src/static/data.json";
    let bot_data = match load_bot_data(bot_data_path) {
        Ok(data) => {
            log::info!("Successfully loaded bot data: {}", data.title);
            data
        },
        Err(err) => {
            log::error!("Failed to load bot data: {}", err);
            return Err(err);
        }
    };
    
    // Initialize shared state with the loaded data
    let state = Arc::new(Mutex::new(AppState {
        message_count: 0,
        bot_data,
        search_states: Arc::new(TokioMutex::new(HashMap::new())),
    }));
    let web_state = state.clone();
    
    // Get the bot token from environment variables
    let bot = Bot::from_env();
    log::info!("Bot token retrieved successfully");

    // Start the web server in a separate task
    let server_task = tokio::spawn(async move {
        // CORS configuration
        let cors = warp::cors()
            .allow_any_origin()
            .allow_methods(vec!["GET", "POST", "OPTIONS"])
            .allow_headers(vec!["Content-Type", "Authorization"])
            .build();

        // Clone web_state for each route that needs it
        let web_state_get = web_state.clone();
        let web_state_save = web_state.clone();

        // Route for serving index.html
        let index = warp::path::end()
            .and(warp::get())
            .and(warp::fs::file("src/static/index.html"));

        // Route for serving static files
        let static_files = warp::path("static")
            .and(warp::fs::dir("src/static"));

        // Route for getting bot data JSON
        let get_data = warp::path("api")
            .and(warp::path("data"))
            .and(warp::get())
            .and(warp::any().map(move || web_state_get.clone()))
            .map(|state: Arc<Mutex<AppState>>| {
                // First try to get data directly from memory rather than file
                let maybe_data = tokio::task::block_in_place(|| {
                    // Use try_lock which is available for tokio::sync::Mutex
                    match state.try_lock() {
                        Ok(state_guard) => {
                            match serde_json::to_value(&state_guard.bot_data) {
                                Ok(data) => Some(data),
                                Err(e) => {
                                    log::error!("Failed to serialize bot data: {}", e);
                                    None
                                }
                            }
                        },
                        Err(_) => {
                            log::debug!("Could not acquire lock for state, falling back to file");
                            None
                        }
                    }
                });
                
                if let Some(data) = maybe_data {
                    // Return data from memory
                    let response = ApiResponse {
                        success: true,
                        message: "Data loaded successfully from cache".to_string(),
                        data: Some(data),
                    };
                    return warp::reply::json(&response);
                }
                
                // Fallback to reading from file
                match fs::read_to_string("src/static/data.json") {
                    Ok(json_data) => {
                        let json: serde_json::Result<serde_json::Value> = serde_json::from_str(&json_data);
                        match json {
                            Ok(data) => {
                                let response = ApiResponse {
                                    success: true,
                                    message: "Data loaded successfully from file".to_string(),
                                    data: Some(data),
                                };
                                warp::reply::json(&response)
                            },
                            Err(_) => {
                                let response = ApiResponse {
                                    success: false,
                                    message: "Failed to parse JSON data".to_string(),
                                    data: None,
                                };
                                warp::reply::json(&response)
                            }
                        }
                    },
                    Err(_) => {
                        let response = ApiResponse {
                            success: false,
                            message: "Failed to read data file".to_string(),
                            data: None,
                        };
                        warp::reply::json(&response)
                    }
                }
            });

        // Route for saving data
        let save_data = warp::path("api")
            .and(warp::path("save"))
            .and(warp::post())
            .and(warp::body::json())
            .and(warp::any().map(move || web_state_save.clone()))
            .map(|data: serde_json::Value, state: Arc<Mutex<AppState>>| {
                // Pretty-print the JSON for better readability when saved
                let pretty_json = match serde_json::to_string_pretty(&data) {
                    Ok(json) => json,
                    Err(_) => {
                        let response = ApiResponse {
                            success: false,
                            message: "Failed to format JSON data".to_string(),
                            data: None,
                        };
                        return warp::reply::json(&response);
                    }
                };

                // Save to file
                match fs::write("src/static/data.json", pretty_json.clone()) {
                    Ok(_) => {
                        // Try to reload the bot data
                        match serde_json::from_str::<BotData>(&pretty_json) {
                            Ok(new_bot_data) => {
                                // Update the bot data in the shared state
                                tokio::spawn(async move {
                                    let mut state_lock = state.lock().await;
                                    state_lock.bot_data = new_bot_data;
                                    log::info!("Bot data reloaded successfully from API");
                                });
                            },
                            Err(e) => {
                                log::error!("Failed to parse saved data as BotData: {}", e);
                                // Continue since the file was saved successfully
                            }
                        };

                        let response = ApiResponse {
                            success: true,
                            message: "Data saved successfully".to_string(),
                            data: None,
                        };
                        warp::reply::json(&response)
                    },
                    Err(e) => {
                        let response = ApiResponse {
                            success: false,
                            message: format!("Failed to save data to file: {}", e),
                            data: None,
                        };
                        warp::reply::json(&response)
                    }
                }
            });

        // Combine all routes
        let routes = index
            .or(static_files)
            .or(get_data)
            .or(save_data)
            .with(cors);  // Apply CORS to all routes

        // Start the server
        let server_addr = ([127, 0, 0, 1], 3030);
        log::info!("Starting web server at http://127.0.0.1:3030");
        log::info!("Static page available at http://127.0.0.1:3030/");
        log::info!("API endpoints available at http://127.0.0.1:3030/api/data and http://127.0.0.1:3030/api/save");
        warp::serve(routes).run(server_addr).await;
    });

    // Create a dispatcher for the Telegram bot
    let bot_state = state.clone();
    let message_state = state.clone();
    let callback_state = state.clone();

    let handler = dptree::entry()
        .branch(
            Update::filter_message()
                .filter_command::<Command>()
                .endpoint(move |bot: Bot, msg: Message, cmd: Command| {
                    let state = bot_state.clone();
                    async move {
                        // Increment message count in shared state
                        {
                            let mut state = state.lock().await;
                            state.message_count += 1;
                        }
                        command_handler(bot, msg, cmd, state).await
                    }
                }),
        )
        .branch(
            Update::filter_message()
                .endpoint(move |bot: Bot, msg: Message| {
                    let state = message_state.clone();
                    async move {
                        handle_message(bot, msg, state).await
                    }
                }),
        )
        .branch(
            Update::filter_callback_query()
                .endpoint(move |bot: Bot, q: CallbackQuery| {
                    let state = callback_state.clone();
                    callback_handler(bot, q, state)
                }),
        );

    // Start the bot
    Dispatcher::builder(bot, handler)
        .enable_ctrlc_handler()
        .build()
        .dispatch()
        .await;

    // Wait for server task to complete (it won't unless there's an error)
    let _ = server_task.await;

    Ok(())
}

// Handler for web server index page
async fn serve_index(state: Arc<Mutex<AppState>>) -> Result<impl warp::Reply, warp::Rejection> {
    let app_state = state.lock().await;
    let count = app_state.message_count;
    let title = &app_state.bot_data.title;
    
    let html = format!(
        r#"<!DOCTYPE html>
<html>
<head>
    <title>Telegram Bot Server</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
        h1 {{ color: #0088cc; }}
        .card {{ border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-top: 20px; }}
        .links {{ margin-top: 15px; }}
        .links a {{ margin-right: 15px; color: #0088cc; }}
    </style>
</head>
<body>
    <h1>Telegram Bot Web Interface</h1>
    <div class="card">
        <p><strong>Bot title:</strong> {}</p>
        <p>Bot is running and has processed <strong>{}</strong> commands.</p>
        <div class="links">
            <a href="/status">View Status Page</a>
            <a href="/static-page">View Static Page</a>
        </div>
    </div>
</body>
</html>"#,
        title, count
    );
    
    Ok(warp::reply::html(html))
}

// Handler for status page
async fn serve_status(state: Arc<Mutex<AppState>>) -> Result<impl warp::Reply, warp::Rejection> {
    let app_state = state.lock().await;
    let count = app_state.message_count;
    let menu_items = app_state.bot_data.main_menu.len();
    
    let html = format!(
        r#"<!DOCTYPE html>
<html>
<head>
    <title>Bot Status</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
        h1 {{ color: #0088cc; }}
        .card {{ border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-top: 20px; }}
        .stat {{ font-size: 24px; font-weight: bold; color: #0088cc; margin: 10px 0; }}
    </style>
    <meta http-equiv="refresh" content="5">
</head>
<body>
    <h1>Bot Status</h1>
    <div class="card">
        <p>Current Statistics:</p>
        <p class="stat">Commands Processed: {}</p>
        <p class="stat">Menu Items: {}</p>
        <p><a href="/">Back to Home</a></p>
    </div>
</body>
</html>"#,
        count, menu_items
    );
    
    Ok(warp::reply::html(html))
}

// Handler for bot commands
async fn command_handler(
    bot: Bot, 
    msg: Message, 
    cmd: Command, 
    state: Arc<Mutex<AppState>>
) -> Result<(), Box<dyn Error + Send + Sync>> {
    match cmd {
        Command::Start => {
            bot.send_message(
                msg.chat.id,
                "Добро пожаловать! Используйте /menu чтобы открыть главное меню."
            )
            .parse_mode(teloxide::types::ParseMode::Html)
            .await?;
        }
        Command::Help => {
            bot.send_message(
                msg.chat.id,
                Command::descriptions().to_string()
            )
            .parse_mode(teloxide::types::ParseMode::Html)
            .await?;
        }
        Command::Options => {
            let keyboard = InlineKeyboardMarkup::new(vec![
                vec![
                    InlineKeyboardButton::callback("Option 1", "option1"),
                    InlineKeyboardButton::callback("Option 2", "option2"),
                ],
                vec![
                    InlineKeyboardButton::callback("Option 3", "option3"),
                ],
            ]);

            bot.send_message(
                msg.chat.id,
                "Choose an option:"
            )
            .parse_mode(teloxide::types::ParseMode::Html)
            .reply_markup(keyboard)
            .await?;
        }
        Command::Menu => {
            send_main_menu(bot, msg.chat.id, &state).await?;
        }
        Command::Faq => {
            send_faq(bot, msg.chat.id, &state).await?;
        }
    }

    Ok(())
}

// Send the main menu based on JSON data
async fn send_main_menu(bot: Bot, chat_id: ChatId, state: &Arc<Mutex<AppState>>) -> Result<(), Box<dyn Error + Send + Sync>> {
    let app_state = state.lock().await;
    let main_menu = &app_state.bot_data.main_menu;
    
    // Create keyboard buttons from main menu items
    let mut keyboard: Vec<Vec<InlineKeyboardButton>> = Vec::new();
    let mut row: Vec<InlineKeyboardButton> = Vec::new();
    
    for (index, item) in main_menu.iter().enumerate() {
        // Add two buttons per row
        if index % 2 == 0 && !row.is_empty() {
            keyboard.push(row);
            row = Vec::new();
        }
        
        row.push(InlineKeyboardButton::callback(
            &item.text,
            &item.callback_data
        ));
    }
    
    // Add the last row if not empty
    if !row.is_empty() {
        keyboard.push(row);
    }
    
    let markup = InlineKeyboardMarkup::new(keyboard);
    
    bot.send_message(
        chat_id,
        &format!("Главное меню: {}", app_state.bot_data.title)
    )
    .parse_mode(teloxide::types::ParseMode::Html)
    .reply_markup(markup)
    .await?;
    
    Ok(())
}

// Edit message to show main menu (used for "Back" navigation)
async fn edit_to_main_menu(bot: Bot, chat_id: ChatId, message_id: teloxide::types::MessageId, state: &Arc<Mutex<AppState>>) -> Result<(), Box<dyn Error + Send + Sync>> {
    let app_state = state.lock().await;
    let main_menu = &app_state.bot_data.main_menu;
    
    // Create keyboard buttons from main menu items
    let mut keyboard: Vec<Vec<InlineKeyboardButton>> = Vec::new();
    let mut row: Vec<InlineKeyboardButton> = Vec::new();
    
    for (index, item) in main_menu.iter().enumerate() {
        // Add two buttons per row
        if index % 2 == 0 && !row.is_empty() {
            keyboard.push(row);
            row = Vec::new();
        }
        
        row.push(InlineKeyboardButton::callback(
            &item.text,
            &item.callback_data
        ));
    }
    
    // Add the last row if not empty
    if !row.is_empty() {
        keyboard.push(row);
    }
    
    let markup = InlineKeyboardMarkup::new(keyboard);
    
    bot.edit_message_text(
        chat_id,
        message_id,
        &format!("Главное меню: {}", app_state.bot_data.title)
    )
    .parse_mode(teloxide::types::ParseMode::Html)
    .reply_markup(markup)
    .await?;
    
    Ok(())
}

// Send FAQ based on JSON data
async fn send_faq(bot: Bot, chat_id: ChatId, state: &Arc<Mutex<AppState>>) -> Result<(), Box<dyn Error + Send + Sync>> {
    let app_state = state.lock().await;
    let faq_items = &app_state.bot_data.faq;
    
    if faq_items.is_empty() {
        bot.send_message(chat_id, "FAQ список пуст")
          .parse_mode(teloxide::types::ParseMode::Html)
          .await?;
        return Ok(());
    }
    
    // Create FAQ keyboard
    let mut keyboard: Vec<Vec<InlineKeyboardButton>> = Vec::new();
    
    for (index, item) in faq_items.iter().enumerate() {
        keyboard.push(vec![InlineKeyboardButton::callback(
            &format!("❓ {}", item.question),
            &format!("faq_{}", index)
        )]);
    }
    
    // Add menu button
    keyboard.push(vec![InlineKeyboardButton::callback("🔙 Главное меню", "main_menu")]);
    
    let markup = InlineKeyboardMarkup::new(keyboard);
    
    bot.send_message(
        chat_id,
        "Часто задаваемые вопросы:"
    )
    .parse_mode(teloxide::types::ParseMode::Html)
    .reply_markup(markup)
    .await?;
    
    Ok(())
}

// Handler for callback queries from inline keyboards
async fn callback_handler(bot: Bot, q: CallbackQuery, state: Arc<Mutex<AppState>>) -> Result<(), Box<dyn Error + Send + Sync>> {
    // If the button has no callback data, do nothing
    if let Some(data) = &q.data {
        // Let the user know we received their callback
        if let Some(message) = q.message {
            let chat_id = message.chat.id;
            
            // Get the state data
            let app_state = state.lock().await;
            
            // Check if this is a search callback
            if data == "search" {
                let markup = InlineKeyboardMarkup::new(vec![
                    vec![InlineKeyboardButton::callback("🔙 Главное меню", "main_menu")]
                ]);
                
                // Mark user as in search mode
                {
                    let mut search_states = app_state.search_states.lock().await;
                    search_states.insert(chat_id, true);
                }
                
                bot.edit_message_text(
                    chat_id,
                    message.id,
                    "🔍 Введите текст для поиска:"
                )
                .parse_mode(teloxide::types::ParseMode::Html)
                .reply_markup(markup)
                .await?;
                
                // Answer the callback query
                bot.answer_callback_query(q.id).await?;
                return Ok(());
            } else if data == "main_menu" {
                // Handle main menu request by editing the current message
                drop(app_state); // Release the lock before the async call
                edit_to_main_menu(bot.clone(), chat_id, message.id, &state).await?;
                
                // Answer the callback query
                bot.answer_callback_query(q.id).await?;
                return Ok(());
            }
            
            // Check if this is a FAQ callback
            if data.starts_with("faq_") {
                if let Ok(index) = data[4..].parse::<usize>() {
                    if let Some(faq_item) = app_state.bot_data.faq.get(index) {
                        let markup = InlineKeyboardMarkup::new(vec![
                            vec![InlineKeyboardButton::callback("◀️ Назад к FAQ", "faq_back")],
                            vec![InlineKeyboardButton::callback("🔙 Главное меню", "main_menu")]
                        ]);
                        
                        // Using HTML formatting instead of Markdown to avoid escaping issues
                        bot.edit_message_text(
                            chat_id,
                            message.id,
                            &format!("❓ <b>{}</b>\n\n{}", escape_html(&faq_item.question), escape_html(&faq_item.answer))
                        )
                        .parse_mode(teloxide::types::ParseMode::Html)
                        .reply_markup(markup)
                        .await?;
                        
                        // Answer the callback query
                        bot.answer_callback_query(q.id).await?;
                        return Ok(());
                    }
                }
            } else if data == "faq_back" {
                // Go back to FAQ list
                drop(app_state); // Release the lock before the async call
                
                // Edit existing message instead of sending a new one
                let faq_app_state = state.lock().await;
                let faq_items = &faq_app_state.bot_data.faq;
                
                if faq_items.is_empty() {
                    bot.edit_message_text(chat_id, message.id, "FAQ список пуст")
                      .parse_mode(teloxide::types::ParseMode::Html)
                      .await?;
                } else {
                    // Create FAQ keyboard
                    let mut keyboard: Vec<Vec<InlineKeyboardButton>> = Vec::new();
                    
                    for (index, item) in faq_items.iter().enumerate() {
                        keyboard.push(vec![InlineKeyboardButton::callback(
                            &format!("❓ {}", item.question),
                            &format!("faq_{}", index)
                        )]);
                    }
                    
                    // Add menu button
                    keyboard.push(vec![InlineKeyboardButton::callback("🔙 Главное меню", "main_menu")]);
                    
                    let markup = InlineKeyboardMarkup::new(keyboard);
                    
                    bot.edit_message_text(
                        chat_id,
                        message.id,
                        "Часто задаваемые вопросы:"
                    )
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .reply_markup(markup)
                    .await?;
                }
                
                // Answer the callback query
                bot.answer_callback_query(q.id).await?;
                return Ok(());
            }
            
            // Try to find the menu item with this callback data
            if let Some(item) = models::find_menu_item(&app_state.bot_data.main_menu, data) {
                // Check if there's a submenu
                if !item.submenu.is_empty() {
                    // Create keyboard from submenu
                    let mut keyboard: Vec<Vec<InlineKeyboardButton>> = Vec::new();
                    let mut row: Vec<InlineKeyboardButton> = Vec::new();
                    
                    for (index, subitem) in item.submenu.iter().enumerate() {
                        // Add two buttons per row
                        if index % 2 == 0 && !row.is_empty() {
                            keyboard.push(row);
                            row = Vec::new();
                        }
                        
                        row.push(InlineKeyboardButton::callback(
                            &subitem.text,
                            &subitem.callback_data
                        ));
                    }
                    
                    // Add back button
                    if !row.is_empty() {
                        keyboard.push(row);
                    }
                    keyboard.push(vec![InlineKeyboardButton::callback("◀️ Назад", "main_menu")]);
                    
                    let markup = InlineKeyboardMarkup::new(keyboard);
                    
                    // Send submenu
                    bot.edit_message_text(
                        chat_id,
                        message.id,
                        &format!("{}: {}", item.text, item.description.as_deref().unwrap_or(""))
                    )
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .reply_markup(markup)
                    .await?;
                } else if let Some(url) = &item.url {
                    // Item has a URL - show it with a button to open
                    let markup = InlineKeyboardMarkup::new(vec![
                        vec![InlineKeyboardButton::url("Открыть ссылку", Url::parse(url).unwrap_or_else(|_| Url::parse("https://example.com").unwrap()))],
                        vec![InlineKeyboardButton::callback("◀️ Назад", "main_menu")]
                    ]);
                    
                    bot.edit_message_text(
                        chat_id,
                        message.id,
                        &format!("{}: {}", item.text, item.description.as_deref().unwrap_or(""))
                    )
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .reply_markup(markup)
                    .await?;
                } else if let Some(documents) = &item.documents {
                    // Item has documents - show them as buttons
                    let mut keyboard: Vec<Vec<InlineKeyboardButton>> = Vec::new();
                    
                    for doc in documents {
                        if let Some(doc_url) = &doc.url {
                            keyboard.push(vec![InlineKeyboardButton::url(
                                &doc.text, 
                                Url::parse(doc_url).unwrap_or_else(|_| Url::parse("https://example.com").unwrap())
                            )]);
                        } else if let Some(callback) = &doc.callback_data {
                            keyboard.push(vec![InlineKeyboardButton::callback(
                                &doc.text,
                                callback
                            )]);
                        }
                    }
                    
                    // Add back button
                    keyboard.push(vec![InlineKeyboardButton::callback("◀️ Назад", "main_menu")]);
                    
                    let markup = InlineKeyboardMarkup::new(keyboard);
                    
                    bot.edit_message_text(
                        chat_id,
                        message.id,
                        &format!("{}: {}", item.text, item.description.as_deref().unwrap_or(""))
                    )
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .reply_markup(markup)
                    .await?;
                } else if let Some(data_fields) = &item.data {
                    // Item has data fields - format and show them
                    let data_message = models::format_data_message(data_fields);
                    
                    let markup = InlineKeyboardMarkup::new(vec![
                        vec![InlineKeyboardButton::callback("◀️ Назад", "main_menu")]
                    ]);
                    
                    // Using HTML formatting instead of MarkdownV2
                    bot.edit_message_text(
                        chat_id,
                        message.id,
                        &format!("{}\n\n{}", item.text, escape_html_links(&data_message))
                    )
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .reply_markup(markup)
                    .await?;
                } else if let Some(text_content) = &item.text_content {
                    // Item has text content - show it
                    let markup = InlineKeyboardMarkup::new(vec![
                        vec![InlineKeyboardButton::callback("◀️ Назад", "main_menu")]
                    ]);
                    
                    bot.edit_message_text(
                        chat_id,
                        message.id,
                        &format!("{}\n\n{}", item.text, text_content)
                    )
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .reply_markup(markup)
                    .await?;
                } else {
                    // Regular item - just show description
                    let description = item.description.as_deref().unwrap_or("Информация отсутствует");
                    
                    let markup = InlineKeyboardMarkup::new(vec![
                        vec![InlineKeyboardButton::callback("◀️ Назад", "main_menu")]
                    ]);
                    
                    bot.edit_message_text(
                        chat_id,
                        message.id,
                        &format!("{}: {}", item.text, description)
                    )
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .reply_markup(markup)
                    .await?;
                }
            } else {
                // Unknown callback data
                let text = match data.as_str() {
                    "option1" => "You selected Option 1!",
                    "option2" => "You selected Option 2!",
                    "option3" => "You selected Option 3!",
                    _ => "Unknown option selected",
                };

                bot.send_message(chat_id, text)
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .await?;
            }
            
            // Answer the callback query to remove the loading indicator
            bot.answer_callback_query(q.id).await?;
        }
    }

    Ok(())
}

// Handle regular messages
async fn handle_message(bot: Bot, msg: Message, state: Arc<Mutex<AppState>>) -> Result<(), Box<dyn Error + Send + Sync>> {
    // Only proceed if the message has text
    if let Some(text) = msg.text() {
        let chat_id = msg.chat.id;
        
        // Check if user is in search mode
        let mut is_searching = false;
        {
            let app_state = state.lock().await;
            let search_states = app_state.search_states.lock().await;
            is_searching = search_states.get(&chat_id).copied().unwrap_or(false);
        }
        
        if is_searching {
            // User is searching, perform search
            let search_results = search_items(text, &state).await;
            
            // Reset search state
            {
                let app_state = state.lock().await;
                let mut search_states = app_state.search_states.lock().await;
                search_states.remove(&chat_id);
            }
            
            // Display search results
            if search_results.is_empty() {
                let markup = InlineKeyboardMarkup::new(vec![
                    vec![InlineKeyboardButton::callback("🔍 Новый поиск", "search")],
                    vec![InlineKeyboardButton::callback("🔙 Главное меню", "main_menu")]
                ]);
                
                bot.send_message(chat_id, "По вашему запросу ничего не найдено.")
                    .parse_mode(teloxide::types::ParseMode::Html)
                    .reply_markup(markup)
                    .await?;
            } else {
                // Create buttons for search results
                let mut keyboard: Vec<Vec<InlineKeyboardButton>> = Vec::new();
                
                for (callback_data, text) in search_results {
                    keyboard.push(vec![InlineKeyboardButton::callback(
                        text, 
                        callback_data
                    )]);
                }
                
                // Add menu buttons
                keyboard.push(vec![InlineKeyboardButton::callback("🔍 Новый поиск", "search")]);
                keyboard.push(vec![InlineKeyboardButton::callback("🔙 Главное меню", "main_menu")]);
                
                let markup = InlineKeyboardMarkup::new(keyboard);
                
                bot.send_message(
                    chat_id,
                    format!("Результаты поиска по запросу \"{}\":", text)
                )
                .parse_mode(teloxide::types::ParseMode::Html)
                .reply_markup(markup)
                .await?;
            }
        }
    }
    
    Ok(())
}

// Search for items matching query
async fn search_items(query: &str, state: &Arc<Mutex<AppState>>) -> Vec<(String, String)> {
    let mut results = Vec::new();
    let query = query.to_lowercase();
    
    let app_state = state.lock().await;
    
    // Helper function to recursively search menu items
    fn search_menu_items(
        items: &[MenuItem], 
        query: &str, 
        results: &mut Vec<(String, String)>,
        max_results: usize
    ) {
        for item in items {
            // Stop if we have enough results
            if results.len() >= max_results {
                return;
            }
            
            // Check if this item matches
            let text_match = item.text.to_lowercase().contains(query);
            let desc_match = item.description.as_ref().map_or(false, |desc| 
                desc.to_lowercase().contains(query)
            );
            
            if text_match || desc_match {
                results.push((item.callback_data.clone(), format!("📌 {}", item.text)));
            }
            
            // Check submenu items
            if !item.submenu.is_empty() {
                search_menu_items(&item.submenu, query, results, max_results);
            }
        }
    }
    
    // Search in menu items
    search_menu_items(&app_state.bot_data.main_menu, &query, &mut results, 10);
    
    // Search in FAQ
    for (index, faq) in app_state.bot_data.faq.iter().enumerate() {
        // Stop if we have enough results
        if results.len() >= 15 {
            break;
        }
        
        let question_match = faq.question.to_lowercase().contains(&query);
        let answer_match = faq.answer.to_lowercase().contains(&query);
        
        if question_match || answer_match {
            results.push((format!("faq_{}", index), format!("❓ {}", faq.question)));
        }
    }
    
    results
}

// Helper function to escape special HTML characters
fn escape_html(text: &str) -> String {
    text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
}

// Helper function to convert Markdown-style links to HTML links
fn escape_html_links(text: &str) -> String {
    let link_regex = regex::Regex::new(r"\[([^\]]+)\]\(([^)]+)\)").unwrap();
    let escaped_text = escape_html(text);
    
    link_regex.replace_all(&escaped_text, r#"<a href="$2">$1</a>"#).to_string()
}
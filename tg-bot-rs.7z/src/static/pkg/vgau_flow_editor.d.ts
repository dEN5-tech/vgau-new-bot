/* tslint:disable */
/* eslint-disable */
export function start(): void;
export class FlowEditor {
  free(): void;
  constructor();
  add_menu_node(x: number, y: number, text: string, callback_data: string, node_type: string, parent_id?: number | null): number;
  add_edge(from: number, to: number, edge_type: string): boolean;
  set_node_property(node_id: number, property: string, value: string): boolean;
  get_children(parent_id: number): Array<any>;
  get_nodes(): Array<any>;
  get_nodes_ecs(): Array<any>;
  get_edges(): Array<any>;
  get_edges_ecs(): Array<any>;
  import_from_json(json_str: string): boolean;
  export_to_json(): string;
  get_root_node_id(): number | undefined;
  update_node_position(node_id: number, x: number, y: number): boolean;
  apply_layout_system(): void;
  simulation_step(delta_time: number): void;
}
export class JSEdge {
  free(): void;
  constructor(from: number, to: number, edge_type: string);
  get_from(): number;
  get_to(): number;
  get_edge_type(): string;
}
export class Node {
  free(): void;
  constructor(id: number, x: number, y: number, text: string, callback_data: string, node_type: string, parent_id?: number | null);
  get_id(): number;
  get_position(): Array<any>;
  set_position(x: number, y: number): void;
  get_text(): string;
  set_text(text: string): void;
  get_callback_data(): string;
  set_callback_data(callback_data: string): void;
  get_description(): string | undefined;
  set_description(description: string): void;
  get_url(): string | undefined;
  set_url(url: string): void;
  get_node_type(): string;
  get_parent_id(): number | undefined;
  set_parent_id(parent_id: number): void;
}
/**
 * Handle for the canvas renderer
 */
export class Renderer {
  free(): void;
  constructor(canvas_id: string);
  /**
   * Resize the canvas to match its container
   */
  resize(): void;
  /**
   * Set the pan offset for navigating the canvas
   */
  set_pan_offset(x: number, y: number): void;
  /**
   * Get the current pan offset
   */
  get_pan_offset(): Array<any>;
  /**
   * Set the zoom scale
   */
  set_scale(scale: number): void;
  /**
   * Get the current zoom scale
   */
  get_scale(): number;
  /**
   * Set the currently selected node
   */
  set_selected_node(node_id?: number | null): void;
  /**
   * Render the flow editor
   */
  render(editor: FlowEditor): void;
  /**
   * Transform screen coordinates to world coordinates
   */
  screen_to_world(screen_x: number, screen_y: number): Array<any>;
  /**
   * Perform hit testing to find a node at the given screen coordinates
   */
  hit_test(editor: FlowEditor, screen_x: number, screen_y: number): number | undefined;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_node_free: (a: number, b: number) => void;
  readonly node_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => number;
  readonly node_get_id: (a: number) => number;
  readonly node_get_position: (a: number) => any;
  readonly node_set_position: (a: number, b: number, c: number) => void;
  readonly node_get_text: (a: number) => [number, number];
  readonly node_set_text: (a: number, b: number, c: number) => void;
  readonly node_get_callback_data: (a: number) => [number, number];
  readonly node_set_callback_data: (a: number, b: number, c: number) => void;
  readonly node_get_description: (a: number) => [number, number];
  readonly node_set_description: (a: number, b: number, c: number) => void;
  readonly node_get_url: (a: number) => [number, number];
  readonly node_set_url: (a: number, b: number, c: number) => void;
  readonly node_get_node_type: (a: number) => [number, number];
  readonly node_get_parent_id: (a: number) => number;
  readonly node_set_parent_id: (a: number, b: number) => void;
  readonly __wbg_jsedge_free: (a: number, b: number) => void;
  readonly jsedge_new: (a: number, b: number, c: number, d: number) => number;
  readonly jsedge_get_from: (a: number) => number;
  readonly jsedge_get_to: (a: number) => number;
  readonly jsedge_get_edge_type: (a: number) => [number, number];
  readonly __wbg_floweditor_free: (a: number, b: number) => void;
  readonly floweditor_new: () => number;
  readonly floweditor_add_menu_node: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => number;
  readonly floweditor_add_edge: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly floweditor_set_node_property: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
  readonly floweditor_get_children: (a: number, b: number) => any;
  readonly floweditor_get_nodes: (a: number) => any;
  readonly floweditor_get_nodes_ecs: (a: number) => any;
  readonly floweditor_get_edges: (a: number) => any;
  readonly floweditor_get_edges_ecs: (a: number) => any;
  readonly floweditor_import_from_json: (a: number, b: number, c: number) => number;
  readonly floweditor_export_to_json: (a: number) => [number, number];
  readonly floweditor_get_root_node_id: (a: number) => number;
  readonly floweditor_update_node_position: (a: number, b: number, c: number, d: number) => number;
  readonly floweditor_apply_layout_system: (a: number) => void;
  readonly floweditor_simulation_step: (a: number, b: number) => void;
  readonly start: () => void;
  readonly __wbg_renderer_free: (a: number, b: number) => void;
  readonly renderer_new: (a: number, b: number) => [number, number, number];
  readonly renderer_resize: (a: number) => [number, number];
  readonly renderer_set_pan_offset: (a: number, b: number, c: number) => void;
  readonly renderer_get_pan_offset: (a: number) => any;
  readonly renderer_set_scale: (a: number, b: number) => void;
  readonly renderer_get_scale: (a: number) => number;
  readonly renderer_set_selected_node: (a: number, b: number) => void;
  readonly renderer_render: (a: number, b: number) => [number, number];
  readonly renderer_screen_to_world: (a: number, b: number, c: number) => any;
  readonly renderer_hit_test: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_2: WebAssembly.Table;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;

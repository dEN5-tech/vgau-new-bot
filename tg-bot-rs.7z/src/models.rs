use serde::{Deserialize, Serialize};
use std::error::Error;
use std::path::Path;
use std::fs;

/// Document structure for menu items
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Document {
    pub text: String,
    #[serde(default)]
    pub callback_data: Option<String>,
    #[serde(default)]
    pub url: Option<String>,
}

/// Specialty structure for educational programs
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Specialty {
    pub code: String,
    pub name: String,
    pub profile: String,
    pub url: String,
}

/// Data fields that can be associated with menu items
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ItemData {
    #[serde(default)]
    pub address: Option<String>,
    #[serde(default)]
    pub phone: Option<String>,
    #[serde(default)]
    pub email: Option<String>,
    #[serde(default)]
    pub hours: Option<String>,
    #[serde(default)]
    pub telegram: Option<String>,
    #[serde(default)]
    pub vk: Option<String>,
    #[serde(default)]
    pub ok: Option<String>,
    #[serde(default)]
    pub contact_page: Option<String>,
    #[serde(default)]
    pub specialties: Option<Vec<Specialty>>,
}

/// Model for menu items with optional submenu, URL, and additional data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MenuItem {
    pub text: String,
    pub callback_data: String,
    #[serde(default)]
    pub description: Option<String>,
    #[serde(default)]
    pub url: Option<String>,
    #[serde(default)]
    pub submenu: Vec<MenuItem>,
    #[serde(default)]
    pub documents: Option<Vec<Document>>,
    #[serde(default)]
    pub data: Option<ItemData>,
    #[serde(default)]
    pub text_content: Option<String>,
}

/// FAQ item structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FaqItem {
    pub question: String,
    pub answer: String,
}

/// Main data structure for the bot configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BotData {
    pub title: String,
    pub main_menu: Vec<MenuItem>,
    #[serde(default)]
    pub faq: Vec<FaqItem>,
}

/// Load the bot data from a JSON file
pub fn load_bot_data(path: impl AsRef<Path>) -> Result<BotData, Box<dyn Error>> {
    let data = fs::read_to_string(path)?;
    let bot_data: BotData = serde_json::from_str(&data)?;
    Ok(bot_data)
}

/// Find a menu item by its callback_data
pub fn find_menu_item<'a>(items: &'a [MenuItem], callback_data: &str) -> Option<&'a MenuItem> {
    for item in items {
        if item.callback_data == callback_data {
            return Some(item);
        }
        
        if !item.submenu.is_empty() {
            if let Some(found) = find_menu_item(&item.submenu, callback_data) {
                return Some(found);
            }
        }
    }
    
    None
}

/// Get direct submenu items for a specific callback_data
pub fn get_submenu<'a>(data: &'a BotData, callback_data: &str) -> Vec<&'a MenuItem> {
    // Check if it's the main menu
    if callback_data == "main_menu" {
        return data.main_menu.iter().collect();
    }
    
    // Find the menu item with this callback_data and return its submenu
    if let Some(item) = find_menu_item(&data.main_menu, callback_data) {
        return item.submenu.iter().collect();
    }
    
    Vec::new()
}

/// Format data fields as a readable message
pub fn format_data_message(data: &ItemData) -> String {
    let mut message = String::new();
    
    if let Some(address) = &data.address {
        message.push_str(&format!("📍 Адрес: {}\n", address));
    }
    
    if let Some(phone) = &data.phone {
        message.push_str(&format!("☎️ Телефон: {}\n", phone));
    }
    
    if let Some(email) = &data.email {
        message.push_str(&format!("📧 Email: {}\n", email));
    }
    
    if let Some(hours) = &data.hours {
        message.push_str(&format!("🕒 Часы работы: {}\n", hours));
    }
    
    // Add social media links if available
    let mut social_links = Vec::new();
    
    if let Some(telegram) = &data.telegram {
        social_links.push(format!("<a href=\"{}\">Telegram</a>", telegram));
    }
    
    if let Some(vk) = &data.vk {
        social_links.push(format!("<a href=\"{}\">ВКонтакте</a>", vk));
    }
    
    if let Some(ok) = &data.ok {
        social_links.push(format!("<a href=\"{}\">Одноклассники</a>", ok));
    }
    
    if !social_links.is_empty() {
        message.push_str("\n📱 Социальные сети: ");
        message.push_str(&social_links.join(", "));
        message.push_str("\n");
    }
    
    // Add specialties if available
    if let Some(specialties) = &data.specialties {
        message.push_str("\n📚 Направления:\n");
        for specialty in specialties {
            message.push_str(&format!(
                "• {} {} «{}»\n",
                specialty.code, specialty.name, specialty.profile
            ));
        }
    }
    
    message
} 
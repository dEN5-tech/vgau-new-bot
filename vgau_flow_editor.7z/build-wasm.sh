#!/bin/bash

# Exit if any command fails
set -e

# Ensure wasm-pack is installed
if ! command -v wasm-pack &> /dev/null; then
    echo "wasm-pack is not installed. Installing it now..."
    cargo install wasm-pack
fi

# Build the WebAssembly package
echo "Building WebAssembly package..."
wasm-pack build --target web

echo "WebAssembly build complete!" 
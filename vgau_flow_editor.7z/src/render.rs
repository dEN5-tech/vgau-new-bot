use wasm_bindgen::prelude::*;
use wasm_bindgen::JsCast;
use web_sys::{CanvasRenderingContext2d, HtmlCanvasElement, Path2d};
use glam::Vec2;
use crate::{FlowEditor, NodeId};

// Style constants
const NODE_WIDTH: f32 = 200.0;
const NODE_HEIGHT: f32 = 40.0;
const NODE_RADIUS: f32 = 8.0;
const SHADOW_BLUR: f32 = 10.0;

// Node style colors
const MENU_ITEM_BORDER: &str = "#0F61D9";
const MENU_ITEM_BG: &str = "#e8f0fe";
const SUBMENU_BORDER: &str = "#34a853";
const SUBMENU_BG: &str = "#e6f4ea";
const ITEM_BORDER: &str = "#fbbc04";
const ITEM_BG: &str = "#fef7e0";
const TITLE_BORDER: &str = "#3B4357";
const TITLE_BG: &str = "#f1f3f4";

/// Handle for the canvas renderer
#[wasm_bindgen]
pub struct Renderer {
    canvas: HtmlCanvasElement,
    context: CanvasRenderingContext2d,
    pan_offset: Vec2,
    scale: f32,
    selected_node_id: Option<NodeId>,
}

#[wasm_bindgen]
impl Renderer {
    #[wasm_bindgen(constructor)]
    pub fn new(canvas_id: &str) -> Result<Renderer, JsValue> {
        // Get canvas element
        let document = web_sys::window().unwrap().document().unwrap();
        let canvas = document.get_element_by_id(canvas_id)
            .unwrap()
            .dyn_into::<HtmlCanvasElement>()?;
        
        // Get canvas context
        let context = canvas.get_context("2d")?
            .unwrap()
            .dyn_into::<CanvasRenderingContext2d>()?;
        
        Ok(Renderer {
            canvas,
            context,
            pan_offset: Vec2::new(0.0, 0.0),
            scale: 1.0,
            selected_node_id: None,
        })
    }
    
    /// Resize the canvas to match its container
    pub fn resize(&self) -> Result<(), JsValue> {
        let document = web_sys::window().unwrap().document().unwrap();
        
        if let Some(container) = document.get_element_by_id("editor-container") {
            let width = container.client_width() as u32;
            let height = container.client_height() as u32;
            
            self.canvas.set_width(width);
            self.canvas.set_height(height);
        }
        
        Ok(())
    }
    
    /// Set the pan offset for navigating the canvas
    pub fn set_pan_offset(&mut self, x: f32, y: f32) {
        self.pan_offset = Vec2::new(x, y);
    }
    
    /// Get the current pan offset
    pub fn get_pan_offset(&self) -> js_sys::Array {
        let result = js_sys::Array::new_with_length(2);
        result.set(0, JsValue::from_f64(self.pan_offset.x as f64));
        result.set(1, JsValue::from_f64(self.pan_offset.y as f64));
        result
    }
    
    /// Set the zoom scale
    pub fn set_scale(&mut self, scale: f32) {
        self.scale = scale;
    }
    
    /// Get the current zoom scale
    pub fn get_scale(&self) -> f32 {
        self.scale
    }
    
    /// Set the currently selected node
    pub fn set_selected_node(&mut self, node_id: Option<NodeId>) {
        self.selected_node_id = node_id;
    }
    
    /// Render the flow editor
    pub fn render(&self, editor: &FlowEditor) -> Result<(), JsValue> {
        self.clear();
        
        // Draw edges first (so they appear behind nodes)
        self.draw_edges(editor)?;
        
        // Draw nodes
        self.draw_nodes(editor)?;
        
        Ok(())
    }
    
    /// Clear the canvas
    fn clear(&self) {
        let canvas_width = self.canvas.width() as f64;
        let canvas_height = self.canvas.height() as f64;
        
        self.context.clear_rect(0.0, 0.0, canvas_width, canvas_height);
    }
    
    /// Transform a world point to screen coordinates
    fn transform_point(&self, point: Vec2) -> Vec2 {
        Vec2::new(
            point.x * self.scale + self.pan_offset.x,
            point.y * self.scale + self.pan_offset.y
        )
    }
    
    /// Transform screen coordinates to world coordinates
    pub fn screen_to_world(&self, screen_x: f32, screen_y: f32) -> js_sys::Array {
        let world_x = (screen_x - self.pan_offset.x) / self.scale;
        let world_y = (screen_y - self.pan_offset.y) / self.scale;
        
        let result = js_sys::Array::new_with_length(2);
        result.set(0, JsValue::from_f64(world_x as f64));
        result.set(1, JsValue::from_f64(world_y as f64));
        result
    }
    
    /// Draw all edges in the editor
    fn draw_edges(&self, editor: &FlowEditor) -> Result<(), JsValue> {
        let edges = editor.get_edges_ecs();
        let nodes = editor.get_nodes_ecs();
        
        // Convert nodes to HashMap for easy lookup
        let mut nodes_map = std::collections::HashMap::new();
        for i in 0..nodes.length() {
            let node = nodes.get(i);
            let id = js_sys::Reflect::get(&node, &JsValue::from_str("id"))?.as_f64().unwrap() as u32;
            let x = js_sys::Reflect::get(&node, &JsValue::from_str("x"))?.as_f64().unwrap() as f32;
            let y = js_sys::Reflect::get(&node, &JsValue::from_str("y"))?.as_f64().unwrap() as f32;
            
            nodes_map.insert(id, Vec2::new(x, y));
        }
        
        // Draw each edge
        for i in 0..edges.length() {
            let edge = edges.get(i);
            let from_id = js_sys::Reflect::get(&edge, &JsValue::from_str("from"))?.as_f64().unwrap() as u32;
            let to_id = js_sys::Reflect::get(&edge, &JsValue::from_str("to"))?.as_f64().unwrap() as u32;
            let edge_type = js_sys::Reflect::get(&edge, &JsValue::from_str("edge_type"))?.as_string().unwrap();
            
            // Get node positions
            if let (Some(from_pos), Some(to_pos)) = (nodes_map.get(&from_id), nodes_map.get(&to_id)) {
                let from_screen = self.transform_point(*from_pos);
                let to_screen = self.transform_point(*to_pos);
                
                // Draw arrow with appropriate color
                let color = if edge_type == "parent_child" {
                    SUBMENU_BORDER
                } else {
                    "#666666"
                };
                
                self.draw_arrow(from_screen.x, from_screen.y, to_screen.x, to_screen.y, color)?;
            }
        }
        
        Ok(())
    }
    
    /// Draw all nodes in the editor
    fn draw_nodes(&self, editor: &FlowEditor) -> Result<(), JsValue> {
        let nodes = editor.get_nodes_ecs();
        
        for i in 0..nodes.length() {
            let node = nodes.get(i);
            let id = js_sys::Reflect::get(&node, &JsValue::from_str("id"))?.as_f64().unwrap() as u32;
            let x = js_sys::Reflect::get(&node, &JsValue::from_str("x"))?.as_f64().unwrap() as f32;
            let y = js_sys::Reflect::get(&node, &JsValue::from_str("y"))?.as_f64().unwrap() as f32;
            let text = js_sys::Reflect::get(&node, &JsValue::from_str("text"))?.as_string().unwrap_or_default();
            let node_type = js_sys::Reflect::get(&node, &JsValue::from_str("node_type"))?.as_string().unwrap_or_default();
            
            // Transform to screen coordinates
            let pos = self.transform_point(Vec2::new(x, y));
            
            // Get node style based on type
            let (border_color, bg_color) = match node_type.as_str() {
                "submenu" => (SUBMENU_BORDER, SUBMENU_BG),
                "item" => (ITEM_BORDER, ITEM_BG),
                "title" => (TITLE_BORDER, TITLE_BG),
                _ => (MENU_ITEM_BORDER, MENU_ITEM_BG), // Default to menu_item
            };
            
            // Add shadow if selected
            if Some(id) == self.selected_node_id {
                self.context.set_shadow_blur(SHADOW_BLUR as f64);
                self.context.set_shadow_color(border_color);
            } else {
                self.context.set_shadow_blur(0.0);
            }
            
            // Draw node background
            self.context.set_fill_style(&JsValue::from_str(bg_color));
            self.context.set_stroke_style(&JsValue::from_str(border_color));
            self.context.set_line_width(2.0);
            
            let width = NODE_WIDTH * self.scale;
            let height = NODE_HEIGHT * self.scale;
            self.draw_rounded_rect(
                pos.x - width / 2.0, 
                pos.y - height / 2.0, 
                width, 
                height, 
                NODE_RADIUS * self.scale
            )?;
            
            self.context.set_shadow_blur(0.0);
            
            // Draw node text
            self.context.set_fill_style(&JsValue::from_str("#333333"));
            self.context.set_font(&format!("{}px sans-serif", 14.0 * self.scale));
            self.context.set_text_align("center");
            self.context.set_text_baseline("middle");
            self.context.fill_text(&text, pos.x as f64, pos.y as f64)?;
            
            // Draw node ID
            self.context.set_font(&format!("{}px sans-serif", 10.0 * self.scale));
            self.context.set_text_align("left");
            self.context.fill_text(
                &format!("ID: {}", id), 
                (pos.x - width / 2.0 + 8.0 * self.scale) as f64, 
                (pos.y - height / 2.0 + 12.0 * self.scale) as f64
            )?;
            
            // Draw node type
            self.context.set_text_align("right");
            self.context.fill_text(
                &node_type, 
                (pos.x + width / 2.0 - 8.0 * self.scale) as f64, 
                (pos.y - height / 2.0 + 12.0 * self.scale) as f64
            )?;
        }
        
        Ok(())
    }
    
    /// Draw a rounded rectangle
    fn draw_rounded_rect(&self, x: f32, y: f32, width: f32, height: f32, radius: f32) -> Result<(), JsValue> {
        self.context.begin_path();
        self.context.move_to((x + radius) as f64, y as f64);
        self.context.arc_to(
            (x + width) as f64, y as f64, 
            (x + width) as f64, (y + height) as f64, 
            radius as f64
        )?;
        self.context.arc_to(
            (x + width) as f64, (y + height) as f64, 
            x as f64, (y + height) as f64, 
            radius as f64
        )?;
        self.context.arc_to(
            x as f64, (y + height) as f64, 
            x as f64, y as f64, 
            radius as f64
        )?;
        self.context.arc_to(
            x as f64, y as f64, 
            (x + width) as f64, y as f64, 
            radius as f64
        )?;
        self.context.close_path();
        
        self.context.fill();
        self.context.stroke();
        
        Ok(())
    }
    
    /// Draw an arrow between two points
    fn draw_arrow(&self, from_x: f32, from_y: f32, to_x: f32, to_y: f32, color: &str) -> Result<(), JsValue> {
        let head_length = 15.0 * self.scale;
        let dx = to_x - from_x;
        let dy = to_y - from_y;
        let angle = dy.atan2(dx);
        
        // Calculate start and end points to account for node size
        let start_x = from_x + (angle.cos() * 20.0 * self.scale);
        let start_y = from_y + (angle.sin() * 20.0 * self.scale);
        
        let dist = (dx * dx + dy * dy).sqrt();
        let end_x = from_x + (angle.cos() * (dist - 20.0 * self.scale));
        let end_y = from_y + (angle.sin() * (dist - 20.0 * self.scale));
        
        // Draw line
        self.context.set_stroke_style(&JsValue::from_str(color));
        self.context.begin_path();
        self.context.move_to(start_x as f64, start_y as f64);
        self.context.line_to(end_x as f64, end_y as f64);
        self.context.stroke();
        
        // Draw arrowhead
        self.context.set_fill_style(&JsValue::from_str(color));
        self.context.begin_path();
        self.context.move_to(end_x as f64, end_y as f64);
        self.context.line_to(
            (end_x - head_length * (angle - std::f32::consts::PI/6.0).cos()) as f64,
            (end_y - head_length * (angle - std::f32::consts::PI/6.0).sin()) as f64
        );
        self.context.line_to(
            (end_x - head_length * (angle + std::f32::consts::PI/6.0).cos()) as f64,
            (end_y - head_length * (angle + std::f32::consts::PI/6.0).sin()) as f64
        );
        self.context.close_path();
        self.context.fill();
        
        Ok(())
    }
    
    /// Perform hit testing to find a node at the given screen coordinates
    pub fn hit_test(&self, editor: &FlowEditor, screen_x: f32, screen_y: f32) -> Option<u32> {
        let nodes = editor.get_nodes_ecs();
        
        for i in 0..nodes.length() {
            let node = nodes.get(i);
            let id = js_sys::Reflect::get(&node, &JsValue::from_str("id")).ok()?.as_f64()? as u32;
            let x = js_sys::Reflect::get(&node, &JsValue::from_str("x")).ok()?.as_f64()? as f32;
            let y = js_sys::Reflect::get(&node, &JsValue::from_str("y")).ok()?.as_f64()? as f32;
            
            // Transform to screen coordinates
            let pos = self.transform_point(Vec2::new(x, y));
            
            // Hit test - simple rectangular check
            let width = NODE_WIDTH * self.scale;
            let height = NODE_HEIGHT * self.scale;
            
            if screen_x >= pos.x - width / 2.0 && screen_x <= pos.x + width / 2.0 &&
               screen_y >= pos.y - height / 2.0 && screen_y <= pos.y + height / 2.0 {
                return Some(id);
            }
        }
        
        None
    }
} 
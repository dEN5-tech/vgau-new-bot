use wasm_bindgen::prelude::*;
use js_sys::{Array, Object, JSON, JsString};
use glam::{Vec2, Vec3};
use std::collections::{HashMap, HashSet};
use hecs::{World, Entity};

mod render;
pub use render::Renderer;

#[wasm_bindgen]
extern "C" {
    // JavaScript console.log
    #[wasm_bindgen(js_namespace = console)]
    fn log(s: &str);
}

// Helper macro for logging to the JavaScript console
macro_rules! console_log {
    ($($t:tt)*) => (log(&format!($($t)*)))
}

// Node ID type
type NodeId = u32;

// ECS Components
#[derive(Debug, Clone)]
struct Position {
    value: Vec2,
}

#[derive(Debug, Clone)]
struct NodeData {
    id: NodeId,
    text: String,
    callback_data: String,
    description: Option<String>,
    url: Option<String>,
    node_type: String,
    parent_id: Option<NodeId>,
}

#[derive(Debug, Clone)]
struct EdgeComponent {
    from: NodeId,
    to: NodeId,
    edge_type: String,
}

// Node structure for menu items in a DAG
#[wasm_bindgen]
pub struct Node {
    id: NodeId,
    position: Vec2,
    text: String,
    callback_data: String,
    description: Option<String>,
    url: Option<String>,
    node_type: String, // "menu", "submenu", "item", etc.
    parent_id: Option<NodeId>,
}

#[wasm_bindgen]
impl Node {
    #[wasm_bindgen(constructor)]
    pub fn new(
        id: NodeId, 
        x: f32, 
        y: f32, 
        text: String, 
        callback_data: String, 
        node_type: String,
        parent_id: Option<NodeId>
    ) -> Self {
        Self {
            id,
            position: Vec2::new(x, y),
            text,
            callback_data,
            description: None,
            url: None,
            node_type,
            parent_id,
        }
    }

    pub fn get_id(&self) -> NodeId {
        self.id
    }

    pub fn get_position(&self) -> Array {
        let result = Array::new_with_length(2);
        result.set(0, JsValue::from_f64(self.position.x as f64));
        result.set(1, JsValue::from_f64(self.position.y as f64));
        result
    }

    pub fn set_position(&mut self, x: f32, y: f32) {
        self.position = Vec2::new(x, y);
    }

    pub fn get_text(&self) -> String {
        self.text.clone()
    }
    
    pub fn set_text(&mut self, text: String) {
        self.text = text;
    }
    
    pub fn get_callback_data(&self) -> String {
        self.callback_data.clone()
    }
    
    pub fn set_callback_data(&mut self, callback_data: String) {
        self.callback_data = callback_data;
    }
    
    pub fn get_description(&self) -> Option<String> {
        self.description.clone()
    }
    
    pub fn set_description(&mut self, description: String) {
        self.description = Some(description);
    }
    
    pub fn get_url(&self) -> Option<String> {
        self.url.clone()
    }
    
    pub fn set_url(&mut self, url: String) {
        self.url = Some(url);
    }
    
    pub fn get_node_type(&self) -> String {
        self.node_type.clone()
    }
    
    pub fn get_parent_id(&self) -> Option<NodeId> {
        self.parent_id
    }
    
    pub fn set_parent_id(&mut self, parent_id: NodeId) {
        self.parent_id = Some(parent_id);
    }
}

// JS-exposed Edge class
#[wasm_bindgen]
pub struct JSEdge {
    from: NodeId,
    to: NodeId,
    edge_type: String, // "parent_child", "link", etc.
}

#[wasm_bindgen]
impl JSEdge {
    #[wasm_bindgen(constructor)]
    pub fn new(from: NodeId, to: NodeId, edge_type: String) -> Self {
        Self { from, to, edge_type }
    }

    pub fn get_from(&self) -> NodeId {
        self.from
    }
    
    pub fn get_to(&self) -> NodeId {
        self.to
    }
    
    pub fn get_edge_type(&self) -> String {
        self.edge_type.clone()
    }
}

// Main FlowEditor structure
#[wasm_bindgen]
pub struct FlowEditor {
    // Legacy data structures for backward compatibility
    nodes: HashMap<NodeId, Node>,
    adjacency_list: HashMap<NodeId, HashSet<NodeId>>,
    
    // ECS World
    world: World,
    
    // Entity mapping
    entity_map: HashMap<NodeId, Entity>,
    
    next_node_id: NodeId,
    root_node_id: Option<NodeId>,
}

#[wasm_bindgen]
impl FlowEditor {
    #[wasm_bindgen(constructor)]
    pub fn new() -> Self {
        console_log!("FlowEditor initialized with ECS");
        Self {
            nodes: HashMap::new(),
            adjacency_list: HashMap::new(),
            world: World::new(),
            entity_map: HashMap::new(),
            next_node_id: 0,
            root_node_id: None,
        }
    }

    // Add a menu node with text and callback data
    pub fn add_menu_node(&mut self, x: f32, y: f32, text: String, callback_data: String, node_type: String, parent_id: Option<u32>) -> NodeId {
        let node_id = self.next_node_id;
        self.next_node_id += 1;
        
        // Create the node for backward compatibility
        let node = Node::new(node_id, x, y, text.clone(), callback_data.clone(), node_type.clone(), parent_id);
        self.nodes.insert(node_id, node);
        self.adjacency_list.insert(node_id, HashSet::new());
        
        // Create an entity with components
        let entity = self.world.spawn((
            Position { value: Vec2::new(x, y) },
            NodeData {
                id: node_id,
                text,
                callback_data,
                description: None,
                url: None,
                node_type,
                parent_id,
            }
        ));
        
        // Store mapping between NodeId and Entity
        self.entity_map.insert(node_id, entity);
        
        // If this is the first node, set it as root
        if self.nodes.len() == 1 {
            self.root_node_id = Some(node_id);
        }
        
        // Connect to parent if specified
        if let Some(parent) = parent_id {
            if self.nodes.contains_key(&parent) {
                if let Some(edges) = self.adjacency_list.get_mut(&parent) {
                    edges.insert(node_id);
                }
                
                // Add edge component to ECS
                let edge = EdgeComponent {
                    from: parent,
                    to: node_id,
                    edge_type: "parent_child".to_string(),
                };
                
                self.world.spawn((edge,));
            }
        }
        
        node_id
    }
    
    // Add directed edge between nodes
    pub fn add_edge(&mut self, from: NodeId, to: NodeId, edge_type: String) -> bool {
        // Check if nodes exist
        if !self.nodes.contains_key(&from) || !self.nodes.contains_key(&to) {
            console_log!("Cannot add edge: one or both nodes don't exist");
            return false;
        }
        
        // Add the edge to legacy adjacency list
        if let Some(edges) = self.adjacency_list.get_mut(&from) {
            edges.insert(to);
            
            // Update parent reference in the child node
            if edge_type == "parent_child" {
                if let Some(node) = self.nodes.get_mut(&to) {
                    node.parent_id = Some(from);
                }
                
                // Update NodeData component in ECS
                if let Some(&entity) = self.entity_map.get(&to) {
                    // Using query_one_mut since we're operating on a known entity
                    if let Ok(mut node_data) = self.world.query_one_mut::<&mut NodeData>(entity) {
                        node_data.parent_id = Some(from);
                    }
                }
            }
            
            // Add edge component to ECS
            let edge = EdgeComponent {
                from,
                to,
                edge_type: edge_type.clone(),
            };
            
            self.world.spawn((edge,));
            
            return true;
        }
        
        false
    }
    
    // Set node properties
    pub fn set_node_property(&mut self, node_id: NodeId, property: &str, value: &str) -> bool {
        // Update legacy node
        if let Some(node) = self.nodes.get_mut(&node_id) {
            match property {
                "text" => node.text = value.to_string(),
                "callback_data" => node.callback_data = value.to_string(),
                "description" => node.description = Some(value.to_string()),
                "url" => node.url = Some(value.to_string()),
                "node_type" => node.node_type = value.to_string(),
                _ => return false,
            }
            
            // Update ECS component
            if let Some(&entity) = self.entity_map.get(&node_id) {
                // Using query_one_mut since we're operating on a known entity
                if let Ok(mut node_data) = self.world.query_one_mut::<&mut NodeData>(entity) {
                    match property {
                        "text" => node_data.text = value.to_string(),
                        "callback_data" => node_data.callback_data = value.to_string(),
                        "description" => node_data.description = Some(value.to_string()),
                        "url" => node_data.url = Some(value.to_string()),
                        "node_type" => node_data.node_type = value.to_string(),
                        _ => {}
                    }
                }
            }
            
            return true;
        }
        false
    }
    
    // Get all child nodes of a given node
    pub fn get_children(&self, parent_id: NodeId) -> Array {
        let result = Array::new();
        
        if let Some(children) = self.adjacency_list.get(&parent_id) {
            for &child_id in children {
                result.push(&JsValue::from_f64(child_id as f64));
            }
        }
        
        result
    }
    
    // Get all nodes as a JS array with their properties
    pub fn get_nodes(&self) -> Array {
        let result = Array::new();
        for (_, node) in &self.nodes {
            let js_node = Object::new();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("id"), &JsValue::from_f64(node.id as f64)).unwrap();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("x"), &JsValue::from_f64(node.position.x as f64)).unwrap();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("y"), &JsValue::from_f64(node.position.y as f64)).unwrap();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("text"), &JsValue::from_str(&node.text)).unwrap();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("callback_data"), &JsValue::from_str(&node.callback_data)).unwrap();
            
            if let Some(ref desc) = node.description {
                js_sys::Reflect::set(&js_node, &JsValue::from_str("description"), &JsValue::from_str(desc)).unwrap();
            }
            
            if let Some(ref url) = node.url {
                js_sys::Reflect::set(&js_node, &JsValue::from_str("url"), &JsValue::from_str(url)).unwrap();
            }
            
            js_sys::Reflect::set(&js_node, &JsValue::from_str("node_type"), &JsValue::from_str(&node.node_type)).unwrap();
            
            if let Some(parent_id) = node.parent_id {
                js_sys::Reflect::set(&js_node, &JsValue::from_str("parent_id"), &JsValue::from_f64(parent_id as f64)).unwrap();
            }
            
            result.push(&js_node);
        }
        result
    }
    
    // Get all nodes using ECS query (more efficient)
    pub fn get_nodes_ecs(&self) -> Array {
        let result = Array::new();
        
        for (entity, (position, node_data)) in self.world.query::<(&Position, &NodeData)>().iter() {
            let js_node = Object::new();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("id"), &JsValue::from_f64(node_data.id as f64)).unwrap();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("x"), &JsValue::from_f64(position.value.x as f64)).unwrap();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("y"), &JsValue::from_f64(position.value.y as f64)).unwrap();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("text"), &JsValue::from_str(&node_data.text)).unwrap();
            js_sys::Reflect::set(&js_node, &JsValue::from_str("callback_data"), &JsValue::from_str(&node_data.callback_data)).unwrap();
            
            if let Some(ref desc) = node_data.description {
                js_sys::Reflect::set(&js_node, &JsValue::from_str("description"), &JsValue::from_str(desc)).unwrap();
            }
            
            if let Some(ref url) = node_data.url {
                js_sys::Reflect::set(&js_node, &JsValue::from_str("url"), &JsValue::from_str(url)).unwrap();
            }
            
            js_sys::Reflect::set(&js_node, &JsValue::from_str("node_type"), &JsValue::from_str(&node_data.node_type)).unwrap();
            
            if let Some(parent_id) = node_data.parent_id {
                js_sys::Reflect::set(&js_node, &JsValue::from_str("parent_id"), &JsValue::from_f64(parent_id as f64)).unwrap();
            }
            
            result.push(&js_node);
        }
        
        result
    }
    
    // Get all edges as a JS array
    pub fn get_edges(&self) -> Array {
        let result = Array::new();
        for (&from, neighbors) in &self.adjacency_list {
            for &to in neighbors {
                let js_edge = Object::new();
                js_sys::Reflect::set(&js_edge, &JsValue::from_str("from"), &JsValue::from_f64(from as f64)).unwrap();
                js_sys::Reflect::set(&js_edge, &JsValue::from_str("to"), &JsValue::from_f64(to as f64)).unwrap();
                
                // Determine edge type based on node relationships
                let edge_type = if let Some(to_node) = self.nodes.get(&to) {
                    if to_node.parent_id == Some(from) {
                        "parent_child"
                    } else {
                        "link"
                    }
                } else {
                    "link"
                };
                
                js_sys::Reflect::set(&js_edge, &JsValue::from_str("edge_type"), &JsValue::from_str(edge_type)).unwrap();
                result.push(&js_edge);
            }
        }
        result
    }
    
    // Get all edges using ECS query (more efficient)
    pub fn get_edges_ecs(&self) -> Array {
        let result = Array::new();
        
        for (_, edge) in self.world.query::<&EdgeComponent>().iter() {
            let js_edge = Object::new();
            js_sys::Reflect::set(&js_edge, &JsValue::from_str("from"), &JsValue::from_f64(edge.from as f64)).unwrap();
            js_sys::Reflect::set(&js_edge, &JsValue::from_str("to"), &JsValue::from_f64(edge.to as f64)).unwrap();
            js_sys::Reflect::set(&js_edge, &JsValue::from_str("edge_type"), &JsValue::from_str(&edge.edge_type)).unwrap();
            result.push(&js_edge);
        }
        
        result
    }
    
    // Import menu structure from JSON
    pub fn import_from_json(&mut self, json_str: &str) -> bool {
        // Clear existing data
        self.nodes.clear();
        self.adjacency_list.clear();
        self.next_node_id = 0;
        self.root_node_id = None;
        
        // Clear ECS world
        self.world = World::new();
        self.entity_map.clear();
        
        // Try to parse the JSON
        let result = match JSON::parse(json_str) {
            Ok(val) => val,
            Err(_) => {
                console_log!("Failed to parse JSON");
                return false;
            }
        };
        
        // Check if the JSON has the expected structure
        if js_sys::Reflect::has(&result, &JsValue::from_str("title")).unwrap_or(false) &&
           js_sys::Reflect::has(&result, &JsValue::from_str("main_menu")).unwrap_or(false) {
            // Create root node for the title
            let title = js_sys::Reflect::get(&result, &JsValue::from_str("title"))
                .unwrap_or(JsValue::from_str("Menu"))
                .as_string()
                .unwrap_or_else(|| "Menu".to_string());
                
            let root_id = self.add_menu_node(400.0, 50.0, title, "root".to_string(), "title".to_string(), None);
            self.root_node_id = Some(root_id);
            
            // Process main menu items
            let main_menu_result = js_sys::Reflect::get(&result, &JsValue::from_str("main_menu"));
            if let Some(main_menu) = main_menu_result.ok() {
                let menu_array = Array::from(&main_menu);
                self.process_menu_items(&menu_array, root_id, 100.0);
                return true;
            }
        }
        
        false
    }
    
    // Helper function to process menu items recursively
    fn process_menu_items(&mut self, items: &Array, parent_id: NodeId, y_offset: f32) -> f32 {
        let mut current_y = y_offset;
        let x_offset = 300.0; // Horizontal spacing between levels
        
        for i in 0..items.length() {
            let item = items.get(i);
            let text = js_sys::Reflect::get(&item, &JsValue::from_str("text"))
                .unwrap_or(JsValue::from_str("Item"))
                .as_string()
                .unwrap_or_else(|| "Item".to_string());
                
            let callback_data = js_sys::Reflect::get(&item, &JsValue::from_str("callback_data"))
                .unwrap_or(JsValue::from_str(""))
                .as_string()
                .unwrap_or_else(|| "".to_string());
            
            // Get parent node's position
            let parent_x = if let Some(parent) = self.nodes.get(&parent_id) {
                parent.position.x
            } else {
                0.0
            };
            
            // Create node with increased x offset from parent
            let node_id = self.add_menu_node(
                parent_x + x_offset, 
                current_y, 
                text, 
                callback_data, 
                "menu_item".to_string(),
                Some(parent_id)
            );
            
            // Add description if present
            let desc_result = js_sys::Reflect::get(&item, &JsValue::from_str("description"));
            if let Some(desc_str) = desc_result.ok().and_then(|desc| desc.as_string()) {
                self.set_node_property(node_id, "description", &desc_str);
            }
            
            // Add URL if present
            let url_result = js_sys::Reflect::get(&item, &JsValue::from_str("url"));
            if let Some(url_str) = url_result.ok().and_then(|url| url.as_string()) {
                self.set_node_property(node_id, "url", &url_str);
            }
            
            // Process submenu if present
            let submenu_result = js_sys::Reflect::get(&item, &JsValue::from_str("submenu"));
            let submenu_height = if let Some(submenu) = submenu_result.ok() {
                if js_sys::Array::is_array(&submenu) {
                    let submenu_array = Array::from(&submenu);
                    // Set node type to submenu
                    self.set_node_property(node_id, "node_type", "submenu");
                    
                    // Process submenu items
                    let submenu_y = self.process_menu_items(&submenu_array, node_id, current_y);
                    submenu_y - current_y
                } else {
                    50.0 // Default height if no submenu
                }
            } else {
                50.0 // Default height if no submenu
            };
            
            current_y += submenu_height.max(50.0);
        }
        
        current_y // Return the final y position
    }
    
    // Export the current DAG structure to JSON
    pub fn export_to_json(&self) -> String {
        // Start with root node
        if let Some(root_id) = self.root_node_id {
            if let Some(root) = self.nodes.get(&root_id) {
                let json = Object::new();
                js_sys::Reflect::set(&json, &JsValue::from_str("title"), &JsValue::from_str(&root.text)).unwrap();
                
                // Export main menu items
                let main_menu = Array::new();
                if let Some(children) = self.adjacency_list.get(&root_id) {
                    for &child_id in children {
                        if let Some(node_json) = self.export_node(child_id) {
                            main_menu.push(&node_json);
                        }
                    }
                }
                
                js_sys::Reflect::set(&json, &JsValue::from_str("main_menu"), &main_menu).unwrap();
                
                // Export FAQ section if it exists
                let faq = Array::new();
                // (FAQ processing would go here)
                
                js_sys::Reflect::set(&json, &JsValue::from_str("faq"), &faq).unwrap();
                
                return js_sys::JSON::stringify(&json)
                    .unwrap_or_else(|_| JsValue::from_str("{}").into())
                    .as_string()
                    .unwrap_or_else(|| "{}".to_string());
            }
        }
        
        "{}".to_string()
    }
    
    // Helper function to export a node and its children to JSON
    fn export_node(&self, node_id: NodeId) -> Option<JsValue> {
        if let Some(node) = self.nodes.get(&node_id) {
            let json = Object::new();
            
            js_sys::Reflect::set(&json, &JsValue::from_str("text"), &JsValue::from_str(&node.text)).unwrap();
            js_sys::Reflect::set(&json, &JsValue::from_str("callback_data"), &JsValue::from_str(&node.callback_data)).unwrap();
            
            if let Some(ref desc) = node.description {
                js_sys::Reflect::set(&json, &JsValue::from_str("description"), &JsValue::from_str(desc)).unwrap();
            }
            
            if let Some(ref url) = node.url {
                js_sys::Reflect::set(&json, &JsValue::from_str("url"), &JsValue::from_str(url)).unwrap();
            }
            
            // Export submenu if this node has children
            if let Some(children) = self.adjacency_list.get(&node_id) {
                if !children.is_empty() {
                    let submenu = Array::new();
                    for &child_id in children {
                        if let Some(child_json) = self.export_node(child_id) {
                            submenu.push(&child_json);
                        }
                    }
                    
                    if submenu.length() > 0 {
                        js_sys::Reflect::set(&json, &JsValue::from_str("submenu"), &submenu).unwrap();
                    }
                }
            }
            
            Some(json.into())
        } else {
            None
        }
    }
    
    // Get the root node ID
    pub fn get_root_node_id(&self) -> Option<NodeId> {
        self.root_node_id
    }
    
    // Update a node's position
    pub fn update_node_position(&mut self, node_id: NodeId, x: f32, y: f32) -> bool {
        // Update in legacy structure
        if let Some(node) = self.nodes.get_mut(&node_id) {
            node.set_position(x, y);
            
            // Update in ECS
            if let Some(&entity) = self.entity_map.get(&node_id) {
                if let Ok(mut position) = self.world.query_one_mut::<&mut Position>(entity) {
                    position.value = Vec2::new(x, y);
                }
            }
            
            return true;
        }
        false
    }
    
    // New ECS-specific methods
    
    // Apply a system to all nodes with Position and NodeData
    pub fn apply_layout_system(&mut self) {
        // Example system: Arrange nodes in a grid
        let mut positions = Vec::new();
        
        // Collect all positions first
        for (i, (entity, (_, node_data))) in self.world.query::<(&Position, &NodeData)>().into_iter().enumerate() {
            // Find column and row based on index
            let row = (i / 5) as f32;
            let col = (i % 5) as f32;
            let new_pos = Vec2::new(100.0 + col * 150.0, 100.0 + row * 100.0);
            positions.push((entity, node_data.id, new_pos));
        }
        
        // Update positions
        for (entity, node_id, new_pos) in positions {
            // Update position in ECS
            if let Ok(mut position) = self.world.query_one_mut::<&mut Position>(entity) {
                position.value = new_pos;
                
                // Also update in legacy structure
                if let Some(node) = self.nodes.get_mut(&node_id) {
                    node.position = new_pos;
                }
            }
        }
    }
    
    // Run a simulation step - useful for animations or physics
    pub fn simulation_step(&mut self, delta_time: f32) {
        // Example: Subtle animation of nodes
        let mut updates = Vec::new();
        
        // First pass: Calculate new positions
        for (entity, (position, node_data)) in self.world.query_mut::<(&mut Position, &NodeData)>() {
            // Simple oscillation
            let entity_f32 = entity.id() as f32;
            let offset = (entity_f32 * 0.1 + delta_time).sin() * 5.0;
            
            position.value.y += offset * delta_time;
            updates.push((node_data.id, position.value));
        }
        
        // Second pass: Update legacy structure
        for (node_id, pos) in updates {
            if let Some(node) = self.nodes.get_mut(&node_id) {
                node.position = pos;
            }
        }
    }
}

// This is called when the WebAssembly module is initialized
#[wasm_bindgen(start)]
pub fn start() {
    console_log!("WASM module initialized with ECS support");
} 
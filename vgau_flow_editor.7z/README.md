# VGAU Flow Editor

A WebAssembly-powered Directed Acyclic Graph (DAG) flow editor.

## Features

- Create nodes with custom labels
- Connect nodes with directed edges
- Automatic cycle detection to maintain DAG property
- Topological sorting of nodes
- Interactive canvas with drag-and-drop node positioning

## Prerequisites

- [Rust](https://www.rust-lang.org/tools/install)
- [wasm-pack](https://rustwasm.github.io/wasm-pack/installer/)

## Building

### On Windows

Run the build script:

```
.\build-wasm.bat
```

### On Unix-based systems (Linux/macOS)

Make the script executable and run it:

```
chmod +x build-wasm.sh
./build-wasm.sh
```

## Running

After building, you can serve the project with any static file server:

### Using Python

```
# Python 3
python -m http.server

# Python 2
python -m SimpleHTTPServer
```

### Using Node.js

```
# Install http-server if you don't have it
npm install -g http-server

# Run the server
http-server
```

Then open your browser and navigate to `http://localhost:8000` (or whatever port your server is using).

## About Directed Acyclic Graphs (DAGs)

A Directed Acyclic Graph (DAG) is a directed graph with no directed cycles. This means it is impossible to start at a vertex and follow a sequence of edges that eventually loops back to the same vertex.

DAGs have numerous applications:
- Task scheduling and dependency management
- Data processing pipelines
- Version control systems
- Bayesian networks
- Workflow management

## Project Structure

- `src/lib.rs` - The Rust WebAssembly code
- `build-wasm.bat` / `build-wasm.sh` - Build scripts
- `index.html` - Example usage of the WebAssembly module

## Dependencies

- `wasm-bindgen` - For JavaScript interop
- `js-sys` - For JavaScript standard library objects
- `glam` - For vector math 